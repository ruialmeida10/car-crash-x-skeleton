package io.codeforall.bootcamp;

public enum CarType {
    FIAT,
    MUSTANG
}
