package io.codeforall.bootcamp;

public class TestGame {

    public static void testeGame(String[] args){


    }
}
